function haskey()
    if Tracker:ProviderCountForCode("key") > 0
    then return true
    else return false
    end
end

function hasharp()
    if Tracker:ProviderCountForCode("sh") > 0
    then return true
    else return false
    end
end

function hasdrop()
    if Tracker:ProviderCountForCode("drop") > 0
    then return true
    else return false
    end
end

function all3()
    if Tracker:ProviderCountForCode("et") > 0 and
       Tracker:ProviderCountForCode("sor") > 0 and
       Tracker:ProviderCountForCode("sos") > 0
       then return true
       else return false
       end
    end