Dragon Warrior Randomizer Tracker

Dragon Warrior by Enix

Dragon Warrior Randomizer by
Mcgrew

EmoTracker Pack by
	theamusedminiature
	twitch.tv/theamusedminiature

Maps are from Dragon's Den >>> woodus.com/den/home.php


		>>>IMPORTANT INFO<<<
The tracker inculdes a vailla map with vinalla locations for all the towns/pickups.
The tracker DOES NOT support building your own map yet. 
This is intended for beginners of the Randomizer to keep track of checks and equipment.
		



		>>>Future Features<<<
- Icorporate miscellaneous flags that include (no magic keys and open charlock)
- Added stat tracker to the layout including current equipment
- Logic for Defeating the Dragon Lord
- Settings tab for alternate win conditions and miscellaneous flags 

		>>>CHANGE LOG<<<
v1.0.0
	-first release



