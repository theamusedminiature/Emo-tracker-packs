Tracker:AddItems("items/all_items.json")

ScriptHost:LoadScript("scripts/logic.lua")

Tracker:AddMaps("maps/maps.json")


Tracker:AddLayouts("layout/items.json")
Tracker:AddLayouts("layout/tracker.json")

Tracker:AddLocations("locations/locations.json")
